

 const menuitem = document.querySelector('.menu');

 const showbtn = document.querySelector('.toggle');

 const closebtn = document.querySelector('.close');


        showbtn.addEventListener('click', e => {
            e.preventDefault();
            menuitem.classList.add('block')
        })

        closebtn.addEventListener('click', e => {
            e.preventDefault();
            menuitem.classList.remove('block');
        })