window.addEventListener('scroll', (e) =>{
    e.preventDefault();
    const menu = document.querySelector('nav');
    const headr =document.querySelector('header');
    menu.classList.toggle('sticky', window.scrollY > 0);
    // headr.classList.toggle('sticky', window.scrollY > 0);
})